# 阿旻同学工具箱导航（PHP MPA）

传统多页面应用，无 SPA 框架、无前端路由、无打包工具。页面由 PHP 服务端直接输出完整 HTML，前端只使用原生 CSS 与本地 jQuery 处理侧栏、点赞等交互。

## 运行

需要 PHP 7.4 或更高版本，建议 8.x：

```bash
cd C:/Users/Administrator/Pictures/TOOL
php -S 127.0.0.1:8080
```

浏览器访问 `http://127.0.0.1:8080/`。

也可以直接放入 Apache/Nginx + PHP 的站点目录，例如 XAMPP 的 `htdocs`。

## 目录结构

```text
TOOL/
├─ index.php                  # MPA 首页/分类页，服务端渲染整页
├─ like.php                   # 点赞计数接口，数据写入 data/likes.json
├─ assets/
│  ├─ css/style.css           # 手写原生 CSS，无框架
│  ├─ js/app.js               # jQuery 交互：侧栏、汉堡菜单、点赞
│  └─ vendor/jquery-3.7.1.min.js
├─ includes/
│  ├─ config.php              # 站点信息与分类配置
│  └─ functions.php           # 数据读取、HTML 转义、卡片模板渲染
├─ data/
│  ├─ sites.json              # 服务端站点数据，285 个站点，8 个分类
│  └─ likes.json              # 点赞计数持久化文件
├─ tools/
│  └─ convert_legacy.py       # 从 legacy/data.js 重新生成 data/sites.json
└─ legacy/                    # 上一版纯静态页面源码备份
```

## 页面与交互

- 分类切换通过普通 `?cat=slug` 链接整页刷新完成，服务端输出对应分类卡片，无前端路由。
- 左侧分类支持桌面端折叠、移动端汉堡菜单抽屉。
- 站点卡片包含名称、简介、favicon、访问链接、点赞数，并在有备用链接时展示额外入口。
- 外部站点链接一律 `target="_blank" rel="noopener noreferrer"` 新标签打开。
- 点赞通过 `like.php` 持久化到 `data/likes.json`，同一浏览器不会重复点赞。

## 数据维护

编辑 `data/sites.json` 即可增删站点或修改分类。重新从旧静态数据生成：

```bash
python tools/convert_legacy.py
```
